import SwiftUI

@main
struct StudyTrackerApp: App {
    var body: some Scene {
        WindowGroup {
            LoginPage()
        }
    }
}

