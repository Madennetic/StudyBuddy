import SwiftUI

struct LoginPage: View {
    @State private var fullName: String = ""
    @State private var email: String = ""
    @State private var universityProgram: String = ""
    @State private var courses: String = ""
    @State private var navigateToStudyPage: Bool = false
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("Register")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                TextField("Full Name", text: $fullName)
                    .textFieldStyle(.roundedBorder)
                    .padding()
                
                TextField("Email Address", text: $email)
                    .textFieldStyle(.roundedBorder)
                    .padding()
                
                TextField("University Program", text: $universityProgram)
                    .textFieldStyle(.roundedBorder)
                    .padding()
                
                TextField("Courses (comma-separated)", text: $courses)
                    .textFieldStyle(.roundedBorder)
                    .padding()
                
                NavigationLink(destination: StudyPage(courses: courses), isActive: $navigateToStudyPage) {
                    EmptyView()
                }
                
                Button(action: {
                    if !fullName.isEmpty && !email.isEmpty && !universityProgram.isEmpty && !courses.isEmpty {
                        navigateToStudyPage = true
                    }
                }) {
                    Text("Next")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .disabled(fullName.isEmpty || email.isEmpty || universityProgram.isEmpty || courses.isEmpty)
            }
            .padding()
        }
    }
}

