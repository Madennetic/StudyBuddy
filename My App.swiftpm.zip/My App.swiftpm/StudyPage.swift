import SwiftUI

struct StudyPage: View {
    let courses: String
    @State private var selectedCourse: String = ""
    @State private var isStudying: Bool = false
    @State private var studyStartTime: Date?
    @State private var studyDuration: TimeInterval = 0
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Select Course")
                .font(.headline)
            
            Picker("Course", selection: $selectedCourse) {
                ForEach(courses.components(separatedBy: ","), id: \.self) { course in
                    Text(course.trimmingCharacters(in: .whitespaces))
                }
            }
            .pickerStyle(WheelPickerStyle())
            .frame(height: 150)
            
            Button(action: {
                if isStudying {
                    // Finish studying
                    if let startTime = studyStartTime {
                        studyDuration += Date().timeIntervalSince(startTime)
                    }
                    isStudying = false
                } else {
                    // Start studying
                    studyStartTime = Date()
                    isStudying = true
                }
            }) {
                Text(isStudying ? "Stop Studying" : "Start Studying")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(isStudying ? Color.red : Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            
            if !isStudying && studyDuration > 0 {
                Text("You studied for \(String(format: "%.2f", studyDuration / 3600)) hours.")
            }
        }
        .padding()
    }
}
