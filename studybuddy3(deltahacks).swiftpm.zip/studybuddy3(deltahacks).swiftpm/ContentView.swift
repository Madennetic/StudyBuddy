import SwiftUI

struct ContentView: View {
    @State private var elapsedTime: Int = 0
    @State private var timer: Timer? = nil
    @State private var isRunning: Bool = false

    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Hello, world!")
            Text("Hi")
            
            // Display the timer
            Text("Elapsed Time: \(elapsedTime) seconds")
                .font(.title)

            // Timer control buttons
            HStack {
                Button(action: startTimer) {
                    Text("Start")
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                Button(action: pauseTimer) {
                    Text("Pause")
                        .padding()
                        .background(Color.orange)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                Button(action: resetTimer) {
                    Text("Reset")
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
            }
        }
        .padding()
    }

    // Timer Functions
    func startTimer() {
        if !isRunning {
            timer?.invalidate() // Clear any existing timer
            timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
                DispatchQueue.main.async {
                    elapsedTime += 1
                }
            }
            isRunning = true
        }
    }

    func pauseTimer() {
        timer?.invalidate()
        isRunning = false
    }

    func resetTimer() {
        timer?.invalidate()
        elapsedTime = 0
        isRunning = false
    }
}
